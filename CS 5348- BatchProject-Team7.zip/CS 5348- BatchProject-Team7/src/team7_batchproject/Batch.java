package team7_batchproject;

import java.util.LinkedHashMap;
import java.util.Map;

public class Batch
{
	private String workingDir;
	private Map<String, Command> commands;
	
	public Batch()
	{
		commands = new LinkedHashMap<String, Command>(); //creating a batch object
	}
	
	public void addCommand(Command command)
	{					
		commands.put(command.getID(), command); //adding to the commands to hash-map table
		System.out.println("added command: " + command.getID());
	}

    public Map<String, Command> getCommands()
    {
        return commands;
    }

    public void setWorkingDir(String wd)
    {
        workingDir = wd;
    }

	public String getWorkingDir()
	{
		return workingDir;
	}
	

}
