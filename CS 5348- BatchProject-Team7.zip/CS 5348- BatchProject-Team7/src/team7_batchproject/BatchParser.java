package team7_batchproject;

import java.io.File;
import java.io.FileInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

//Using java inbuilt DOM XML parsing functions to parse the XML files

public class BatchParser
{	
	protected static Batch buildBatch(File f) {
        Batch theBatch = new Batch();

        try {
            FileInputStream fis = new FileInputStream(f);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fis);

            Element pnode = doc.getDocumentElement();
            NodeList nodes = pnode.getChildNodes();
            parseCommand(nodes, theBatch);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        return theBatch;
    }
	
	private static void parseCommand(NodeList nodeList, Batch theBatch) throws ProcessException
	{
		for (int idx = 0; idx < nodeList.getLength(); idx++)
		{
			Node node = nodeList.item(idx);
			if (node.getNodeType() == Node.ELEMENT_NODE)
			{
				Element elem = (Element) node;
				Command newCommand = buildCommand(elem);
				theBatch.addCommand(newCommand);

				if (node.hasChildNodes()) // commands having nested nodes (pipes)
				{
					System.out.println("Parsing child nodes of " + elem.getNodeName());
					NodeList childNodes = node.getChildNodes();
					parseCommand(childNodes, theBatch);
				}
			}
		}
	}
	
	// Traversing the XML nodes to extract the command
	private static Command buildCommand(Element elem) throws ProcessException
	{
		String cmdName = elem.getNodeName();
		Command cmd;
		
		if (cmdName == null)
			throw new ProcessException("unable to parse command from " + elem.getTextContent());
		else if ("wd".equalsIgnoreCase(cmdName))
		{
			System.out.println("Wd command parsing");
			cmd = new WDCommand();
			cmd.parse(elem);
		}
		else if ("file".equalsIgnoreCase(cmdName))
		{
			System.out.println("File command parsing");
			cmd = new FileCommand();
			cmd.parse(elem);
		}
		else if ("cmd".equalsIgnoreCase(cmdName))
		{
			if (elem.getParentNode().getNodeName().equalsIgnoreCase("pipe")) //checking with parent node.
			{
				System.out.println("Pipe command parsing");
				cmd = new PipeCmdCommand();
				cmd.parse(elem);
			}
			else
			{
				System.out.println("Cmd command parsing ");
				cmd = new CmdCommand();
				cmd.parse(elem);
			}
		}
		else if ("pipe".equalsIgnoreCase(cmdName))
		{
			System.out.println("Pipe command parsing");
			cmd = new PipeCommand();
			cmd.parse(elem);
		}
		else
			throw new ProcessException("Unknown command " + cmdName + " from: " + elem.getBaseURI());
		
		return cmd;
	}
}
