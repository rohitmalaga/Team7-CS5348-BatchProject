package team7_batchproject;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

public class BatchProcessor
{
	public static void main(String[] args) throws IOException, InterruptedException, ProcessException
	{
        //Check for the number of input arguments given from command prompt
		if (args.length != 1)		{
			System.err.println("Invalid command, Need exactly one argument for BatchProcessor");
			System.exit(0);
		}

        File f = new File(args[0]);

		if (!f.exists())		{
		  System.out.println("Invalid argument: " + f + " does not exist or invalid location");
		  System.exit(1);
		}

		System.out.println("BatchProcessor started for: "+ f);

        //xml parsing is done here

        Batch theBatch = BatchParser.buildBatch(f);

		System.out.println("Batch parsing finished " + f);

		// Starting batch execution
		System.out.println("Batch executing" + f);
        executeBatch(theBatch);

        // Notifies batch is completed
    	System.out.println("Batch completed " + f);
	}
	
	public static void executeBatch(Batch batch) throws IOException, InterruptedException, ProcessException
	{	
		Map<String, Command> batchCommands = batch.getCommands();
		
		for (Entry<String, Command> entry : batchCommands.entrySet())
		{
			System.out.println(batchCommands.get(entry.getKey()).describe());
            entry.getValue().execute(batch.getWorkingDir(), batch);
		}
		System.out.println("batch completed execution!");
	}
}