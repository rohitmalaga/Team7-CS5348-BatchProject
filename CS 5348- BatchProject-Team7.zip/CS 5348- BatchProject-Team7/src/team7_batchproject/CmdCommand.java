package team7_batchproject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.w3c.dom.Element;

public class CmdCommand extends Command
{
	private String id, path, inID, outID;
	private List<String> cmdArgs;

	public void parse(Element element) throws ProcessException
	{
        System.out.println("Parsing Cmd command attributes");	
        
		id = element.getAttribute("id");
		if (id == null || id.isEmpty())
			throw new ProcessException("Missing ID in CmdCommand");
		System.out.println("ID: " + id);
		
		path = element.getAttribute("path");
		if (path == null || path.isEmpty())
			throw new ProcessException("Missing PATH in CmdCommand");
		System.out.println("Path: " + path);

		cmdArgs = new ArrayList<String>();
		String arg = element.getAttribute("args");
		
		if (!(arg == null || arg.isEmpty()))
		{
			StringTokenizer st = new StringTokenizer(arg);
			while (st.hasMoreTokens())
			{
				String tok = st.nextToken();
				cmdArgs.add(tok);
			}
		}
		for (String argi: cmdArgs)
			System.out.println("Arg " + argi);

		
		inID = element.getAttribute("in");
		if (!(inID == null || inID.isEmpty()))
			System.out.println("inID: " + inID);

		
		outID = element.getAttribute("out");
		if (!(outID == null || outID.isEmpty()))
			System.out.println("outID: " + outID);		
	}
	

	public String describe()
	{
		if (id != null)
			return "Cmd Command description" +"\n"+ id + "\npath=" + path +
					" \nin=" + inID + " \nout=" + outID;
		else
			return "No command to process";
	}

	public void execute(String workingDir, Batch theBatch) throws IOException, InterruptedException, ProcessException
	{		
		List<String> command = new ArrayList<String>();
		command.add(path);
		for (String s : cmdArgs)
		{
			command.add(s);
		}
		
		System.out.println("Commands in Cmd:");
		for (String s : command)
		{
			System.out.println(s);
		}

		ProcessBuilder builder = new ProcessBuilder(command);
		
		builder.directory(new File(workingDir));
		builder.redirectError(new File(workingDir, "error.txt"));

		if (!(inID == null || inID.isEmpty()))
		{
	        if (theBatch.getCommands().containsKey(inID)) {
	            inID = theBatch.getCommands().get(inID).getPath();
	
	            builder.redirectInput(new File(workingDir, inID));
	            System.out.println("Reading from input file: " + inID);
	        }
	        else
	        {  // For batch5.broken.xml Error Handler
				throw new ProcessException("\nError in processing Batch: " +
						"CmdCommand: Unable to locate IN FileCommand with id: " + inID);
			}
	    }

		if (!(outID == null || outID.isEmpty()))
		{
	        if (theBatch.getCommands().containsKey(outID))
	        {
	            outID = theBatch.getCommands().get(outID).getPath();
	            builder.redirectOutput(new File(workingDir, outID));
	            System.out.println("writing to ouput file " + outID);
	        }
	        else
			{// For batch5.broken.xml Error Handler
				throw new ProcessException(
						"\nError Processing Batch: " +
						"CmdCommand: Unable to locate OUT FileCommand with id: " + outID);
			}
		}
		
		final Process process = builder.start();
		process.waitFor();	
		System.out.println("CmdCommand finished executing");
	}

	public String getID()
	{
		return id;
	}

	public String getPath()
	{
		return path;
	}
}
