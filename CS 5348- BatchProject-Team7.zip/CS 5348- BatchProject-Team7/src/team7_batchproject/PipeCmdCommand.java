package team7_batchproject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.w3c.dom.Element;

public class PipeCmdCommand extends Command
{
	private String id, parentID, path, inID, outID;
	private List<String> cmdArgs;
	private FileInputStream f;

	public void parse(Element element) throws ProcessException
	{
		System.out.println("Parsing pipecmd element attributes");
		
		id = element.getAttribute("id");
		if (id == null || id.isEmpty())
			throw new ProcessException("Missing the ID in PipeCmdCommand");
		System.out.println("ID: " + id);
		
		Element parentElem = (Element) element.getParentNode();
		parentID = parentElem.getAttribute("id");
		System.out.println("parentID: " + parentID);
		
		path = element.getAttribute("path");
		if (path == null || path.isEmpty())
			throw new ProcessException("Missing the PATH in PipeCmdCommand");
		System.out.println("Path: " + path);

		cmdArgs = new ArrayList<String>();
		String arg = element.getAttribute("args");
		if (!(arg == null || arg.isEmpty()))
		{
			StringTokenizer st = new StringTokenizer(arg);
			while (st.hasMoreTokens())
			{
				String tok = st.nextToken();
				cmdArgs.add(tok);
			}
		}
		for (String argi: cmdArgs)
			System.out.println("Arg " + argi);

		inID = element.getAttribute("in");
		if (!(inID == null || inID.isEmpty()))
			System.out.println("inID: " + inID);

		outID = element.getAttribute("out");
		if (!(outID == null || outID.isEmpty()))
			System.out.println("outID: " + outID);
	}

	public String describe()
	{
		if (id != null)
			return "PipeCommand description\n" + id + "\npath=" + path +	"\nin=" + inID + "\nout=" + outID;
		else
			return "No command to process ";
	}

	public void execute(String workingDir, Batch batch) throws IOException, ProcessException, InterruptedException
	{
		List<String> command = new ArrayList<String>();
		command.add(path);
		System.out.println("path"+ path);
		System.out.println("inputId"+ inID);
		System.out.println("outputId"+ outID);

		for (String s : cmdArgs) {
			command.add(s);
		}
		
		System.out.println("List of pipe commands:");
		for (String s : command) {
			System.out.println(s);
		}

		ProcessBuilder builder = new ProcessBuilder(command);
		builder.directory(new File(workingDir));
		builder.redirectError(new File(workingDir, "error.txt"));

		PipeCommand pc = (PipeCommand)batch.getCommands().get(parentID);

		if (!(inID == null || inID.isEmpty()))
		{
			if (batch.getCommands().containsKey(inID)) {
	            pc.pipeProcess1 = builder.start();
	            OutputStream os = pc.pipeProcess1.getOutputStream();
	
	            inID = batch.getCommands().get(inID).getPath();
	            f = new FileInputStream(new File(workingDir, inID));
	
	            System.out.println("writing to pipeProcess1's ouput stream from " + inID);
	
	            int achar;
	            while ((achar = f.read()) != -1)
	            {
	                os.write(achar);
	            }
	
	            os.close();
	        }
			else
			{ // For batch5.broken.xml Error Handler
				throw new ProcessException(
						"\nError in Processing Batch: " +
						"CmdCommand: Unable to locate IN FileCommand with id: " + inID);
			}
		}
		
		if (!(outID == null || outID.isEmpty()))
		{
	        if (batch.getCommands().containsKey(outID)) {
	            pc.pipeProcess2 = builder.start();
	            InputStream is1 = pc.pipeProcess1.getInputStream();
	            OutputStream os2 = pc.pipeProcess2.getOutputStream();
	
	            System.out.println("Writing to pipeProcess2's ouput stream from " +
	                             "pipeProcess1's input stream");
	
	            int achar;
	            while ((achar = is1.read()) != -1)
	            {
	                os2.write(achar);
	            }
	
	            os2.close();
	
	            outID = batch.getCommands().get(outID).getPath();
	            File outputFile = new File(workingDir, outID);
	            OutputStream fos = new FileOutputStream(outputFile);
	            InputStream is2 = pc.pipeProcess2.getInputStream();
	
	            System.out.println("Writing to "+ outID + " from " +
	                     "pipeProcess2's input stream");
	
	            System.out.print("contents of " + outID + ": ");
	            while ((achar = is2.read()) != -1)
	            {
	                fos.write(achar);
	                System.out.print((char) achar);
	            }
	
	            fos.close();
	        }
	        else
				{// For batch5.broken.xml Error Handler
					throw new ProcessException(
							"\nError in Processing Batch: " +
							"PipeCmdCommand: Unable to locate OUT FileCommand with id: " + outID);
				}
		}
		System.out.println("PipeCmdCommand finished executing");
	}

	public String getID()
	{
		return id;
	}

	public String getPath()
	{
		return path;
	}
}
