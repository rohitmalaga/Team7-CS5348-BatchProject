package team7_batchproject;

import org.w3c.dom.Element;

public class PipeCommand extends Command
{
	private String id, path;
	public Process pipeProcess1, pipeProcess2;

	public void parse(Element element) throws ProcessException
	{
		System.out.println("Parsing PipeCommand element attributes");

		id = element.getAttribute("id");
		if (id == null || id.isEmpty())
			throw new ProcessException("Missing ID in PipeCommand");
		System.out.println("ID: " + id);
	}

	public String describe()
	{
		if (id != null)
			return "PipeCommand description\n" + "id=" + id;
		else
			return "No command to process";
	}

	public void execute(String workingDir, Batch b)
	{
		System.out.println("PipeCommand finished executing");
	}

	public String getID()
	{
		return id;
	}

	public String getPath()
	{
		return path;
	}
}
