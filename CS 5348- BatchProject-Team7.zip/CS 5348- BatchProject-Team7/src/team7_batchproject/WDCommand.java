package team7_batchproject;

import org.w3c.dom.Element;

public class WDCommand extends Command
{
	private String id, path;

	public void parse(Element element) throws ProcessException
	{
		System.out.println("Parsing WD command element attributes");

		id = element.getAttribute("id");
		if (id == null || id.isEmpty())
			throw new ProcessException("Missing the ID in WDCommand");
		System.out.println("ID: " + id);

		path = element.getAttribute("path");
		if (path == null || path.isEmpty())
			throw new ProcessException("Missing PATH in WDCommand");
		System.out.println("Path: " + path);
	}

	public String describe()
	{
		if (id != null)
			return "WDCommand description"  + "\n" + id + "\npath=" + path;
		else
			return "No command to process";
	}

	public void execute(String workingDir, Batch theBatch) throws ProcessException
	{		
		if (path == null || path.isEmpty())
			throw new ProcessException("Missing the PATH in WD Command");
		else
		{
			theBatch.setWorkingDir(path);
			System.out.println("Working directory set to '" + theBatch.getWorkingDir() + "'");
		}
		System.out.println("WDCommand finished executing");
	}

	public String getID()
	{
		return id;
	}

	public String getPath()
	{
		return path;
	}
}
